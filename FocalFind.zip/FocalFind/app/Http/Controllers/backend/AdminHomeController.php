<?php

namespace App\Http\Controllers\backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminHomeController extends Controller
{
   public function adminhome()
    {
     return view('backend.adminindex');
    }
}
