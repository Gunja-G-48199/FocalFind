 </div>
		<!-- /Main Wrapper -->
		
		<!-- jQuery -->
        <script src="<?php echo e(url('admin_assets/js/jquery-3.2.1.min.js')); ?>"></script>
		
		<!-- Bootstrap Core JS -->
        <script src="<?php echo e(url('admin_assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(url('admin_assets/js/bootstrap.min.js')); ?>"></script>
		
		<!-- Slimscroll JS -->
        <script src="<?php echo e(url('admin_assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
		
		<script src="<?php echo e(url('admin_assets/plugins/raphael/raphael.min.js')); ?>"></script>    
		<script src="<?php echo e(url('admin_assets/plugins/morris/morris.min.js')); ?>"></script>  
		<script src="<?php echo e(url('admin_assets/js/chart.morris.js')); ?>"></script>
		
		<!-- Custom JS -->
		<script  src="<?php echo e(url('admin_assets/js/script.js')); ?>"></script>
		
    </body>

<!-- Mirrored from dreamguys.co.in/demo/doccure/admin/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 30 Nov 2019 04:12:34 GMT -->
</html><?php /**PATH C:\xampp\htdocs\FocalFind\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>